﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3_DataStructures
{
    class ArrayAndMap
    {
        // Class member variable declaration/assignment.
        public static Hashtable myHash = new Hashtable();
        public static LinkedList<string> myList = new LinkedList<string>();

        // Add inputValue into Table at inputKey.
        public void addElementToTable(string inputValue, int inputKey)
        {
            myHash.Add(inputKey, inputValue);
        }

        //Add inputValue to end of list.
        public void addElementToList(string inputValue)
        {
            myList.AddLast(inputValue);
        }
    }
}
