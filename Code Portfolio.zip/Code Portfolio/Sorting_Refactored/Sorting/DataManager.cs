﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sorting
{
    // Data manager is a helper class.
    // Manages data in program.
    class DataManager
    {
        // Memeber variable declaration/instantiation.
        public int[]  dataCopy = new int[474];

        // CopyData returns a new array that is a copy of inputData.
        // Takes an integer array as its argument.
        public int[] CopyData(int[] inputData)
        {
            // Iterate over array.
            for(int i = 0; i < inputData.Length; i++)
            {
                // Value of element at index i in dataCopy set to value of element in inputData array at index i.
                dataCopy[i] = inputData[i];
            }
            return dataCopy;
        }

        // Outputs array to the console as a comma delimited list for readability.
        public void displayData()
        {
            Console.WriteLine("[{0}]", string.Join(", ", dataCopy));
        }
    }
}
