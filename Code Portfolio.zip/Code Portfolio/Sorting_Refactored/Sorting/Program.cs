﻿using System;
using System.IO;

namespace Sorting
{
    class Program
    {
        // Variable declarations/assignments
        static int SIZE = 474;
        static string filePath = "..\\scores.txt";
        static StreamReader myStreamReader = new StreamReader(filePath);
        static int[] dataSet = new int[SIZE];
        static string currLine;
        static DataManager myDataManager = new DataManager();
        static Bubble myBubbleSort = new Bubble();
        static Insertion myInsertionSort = new Insertion();
        static Selection mySelectionSort = new Selection();
        static Heap myHeapSort = new Heap();
        static Quick myQuickSort = new Quick();
        static Merge myMergeSort = new Merge();


        static void Main()
        {
            // Program Entry Point.

            // Populates dataSet with values from scores.txt.
            popDataSet();
            // Display unsorted data set to console.
            displayRawDataSet();
            // Run Bubble sort.
            runBubbleSort();
            // Run Insertion sort.
            runInsertionSort();
            // Run Selection sort.
            runSelectionSort();
            // Run Heap sort.
            runHeapSort();
            // Run Quick sort.
            runQuickSort();
            // Run Merge sort.
            runMergeSort();
            // Display algorithm table to console.
            dispSortAlgTable();

            // Program exit.
        }

        // Method that fills dataSet array with values from scores.txt
        static void popDataSet() 
        {
            // iterates over array
            for (int i = 0; i < SIZE; i++)
            {
                // Store value line
                currLine = myStreamReader.ReadLine();
                dataSet[i] = int.Parse(currLine);
            }
        }

        // Method that outputs unsorted data set to console.
        static void displayRawDataSet()
        {
            Console.WriteLine("Unsorted Data Set");
            Console.WriteLine("[{0}]", string.Join(", ", dataSet));
            Console.WriteLine("\n");
        }

        // Method that evokes BubbleSort method on myBubbleSort,
        // then outputs sorting algorithm info to console.
        static void runBubbleSort()
        {
            // Executes Bubble Sort algorithm
            // passes in copy of dataSet by evoking CopyData method on myDataManger.
            myBubbleSort.BubbleSort(myDataManager.CopyData(dataSet));
            Console.WriteLine("Bubble Sort Method");
            Console.WriteLine("Asymptotic Notation");
            Console.WriteLine(" Best Case: O(n^2)");
            Console.WriteLine("Worst Case: O(n^2)");
            myDataManager.displayData();
            Console.WriteLine("Executed in: " + myBubbleSort.runTime);
            Console.WriteLine("\n");
        }

        // Method that evokes InsertionSort method on myInsertionSort,
        // then outputs sorting algorithm info and sorted data set to console.
        static void runInsertionSort()
        {
            // Executes Insertion Sort algorithm
            // passes in copy of dataSet by evoking CopyData method on myDataManger.
            myInsertionSort.InsertionSort(myDataManager.CopyData(dataSet));
            Console.WriteLine("Insertion Sort Method");
            Console.WriteLine("Asymptotic Notation");
            Console.WriteLine(" Best Case: O(n)");
            Console.WriteLine("Worst Case: O(n^2)");
            myDataManager.displayData();
            Console.WriteLine("Executed in: " + myInsertionSort.runTime);
            Console.WriteLine("\n");
        }

        // Method that evokes SelectionSort method on mySelectionSort,
        // then outputs sorting algorithm info and sorted data set to console.
        static void runSelectionSort()
        {
            // Executes Selection Sort algorithm
            // passes in copy of dataSet by evoking CopyData method on myDataManger.
            mySelectionSort.SelectionSort(myDataManager.CopyData(dataSet));
            Console.WriteLine("Selection Sort Method");
            Console.WriteLine("Asymptotic Notation");
            Console.WriteLine(" Best Case: O(n^2)");
            Console.WriteLine("Worst Case: O(n^2)");
            myDataManager.displayData();
            Console.WriteLine("Executed in: " + mySelectionSort.runTime);
            Console.WriteLine("\n");
        }

        // Method that evokes HeapSort method on myHeapSort,
        // then outputs sorting algorithm info and sorted data set to console.
        static void runHeapSort()
        {
            // Executes Heap Sort algorithm 
            // passes in copy of dataSet by evoking CopyData method on myDataManger.
            myHeapSort.HeapSort(myDataManager.CopyData(dataSet));
            Console.WriteLine("Heap Sort Method");
            Console.WriteLine("Asymptotic Notation");
            Console.WriteLine(" Best Case: O(n log n)");
            Console.WriteLine("Worst Case: O(n log n)");
            myDataManager.displayData();
            Console.WriteLine("Executed in: " + myHeapSort.runTime);
            Console.WriteLine("\n");
        }

        // Method that evokes QuickSort method on myQuickSort,
        // then outputs sorting algorithm info and sorted data set to console.
        static void runQuickSort()
        {
            // Executes Quick Sort algorithm
            // passes in copy of dataSet by evoking CopyData method on myDataManger.
            myQuickSort.QuickSort(myDataManager.CopyData(dataSet), dataSet.GetLowerBound(0), dataSet.GetUpperBound(0));
            Console.WriteLine("Quick Sort Method");
            Console.WriteLine("Asymptotic Notation");
            Console.WriteLine(" Best Case: O(n log n)");
            Console.WriteLine("Worst Case: O(n^2)");
            myDataManager.displayData();
            Console.WriteLine("Executed in: " + myQuickSort.runTime);
            Console.WriteLine("\n");
        }

        // Method that evokes SortHalfs method on myMergeSort,
        // then outputs sorting algorithm info and sorted data set to console.
        static void runMergeSort()
        {
            // Executes Merge Sort algorithm
            // passes in copy of dataSet by evoking CopyData method on myDataManger.
            myMergeSort.SortHalfs(myDataManager.CopyData(dataSet), dataSet.GetLowerBound(0), dataSet.GetUpperBound(0));
            Console.WriteLine("Merge Sort Method");
            Console.WriteLine("Asymptotic Notation");
            Console.WriteLine(" Best Case: O(n log n)");
            Console.WriteLine("Worst Case: O(n log n)");
            myDataManager.displayData();
            Console.WriteLine("Executed in: " + myMergeSort.runTime);
            Console.WriteLine("\n");
        }

        // Method that outputs table of algorithm names and their runtimes.
        static void dispSortAlgTable()
        {
            Console.WriteLine("___Algorithm____|____Runtimes_______");
            Console.WriteLine("   Bubble       |   " + myBubbleSort.runTime);
            Console.WriteLine("  Insertion     |   " + myInsertionSort.runTime);
            Console.WriteLine("  Selection     |   " + mySelectionSort.runTime);
            Console.WriteLine("    Heap        |   " + myHeapSort.runTime);
            Console.WriteLine("    Quick       |   " + myQuickSort.runTime);
            Console.WriteLine("    Merge       |   " + myMergeSort.runTime);
        }
    }
}
