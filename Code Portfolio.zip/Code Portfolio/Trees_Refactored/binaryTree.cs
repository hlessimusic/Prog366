﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trees
{
    class binaryTree
    {
        // binaryTree class member variables.
        private Node Root;
        public Node before;
        public Node after;

        // Returns Root node.
        public Node getRoot()
        {
            return Root;
        }

        // Takes node as argument.
        // Assigns passed in node to Root node.
        public void setRoot(Node inputNode)
        {
            Root = inputNode;
        }

        // Primary Method for constructing binary tree data structure.
        // Creates node with value of given input value.
        // Places node into respective position in tree.
        public bool addChild(int inputValue)
        {
            before = null;
            after = this.Root;

            // if there are nodes bellow in tree structure
            while (after != null)
            {
                // push node up tree
                before = after;

                // Places nodes up correct tree path.
                if (inputValue < after.getNodeValue())
                {
                    after = after.getLeftChild();
                }
                else if (inputValue > after.getNodeValue())
                {
                    after = after.getRightChild();
                }
                else
                {
                    // This should never run.
                    return false;
                }
            }

            // Create new node with value of inputValue
            Node newChild = new Node();
            newChild.setNodeValue(inputValue);

            // If there is no Root node yet (first node placed in Tree), the newChild node is the Root. 
            if(this.Root == null)
            {
                // Only runs once upon starting tree construction.
                this.Root = newChild;
            }
            else
            {
                // Root exists so newChild node is added further down tree.

                if(inputValue < before.getNodeValue())
                {
                    // Move newChild into left subtree.
                    before.setLeftChild(newChild);
                }
                else
                {
                    // Move newChild into right subtree.
                    before.setRightChild(newChild);
                }
            }
            return true;
        }

        // Traverse tree structure by PreOrder traversal and display entire binary tree structure.
        // Always displays Root node first.
        // Then left subtree.
        // Then right subtree.
        public void traverseTree(Node inputParent)
        {
            if (inputParent != null)
            {
                Console.Write(inputParent.getNodeValue() + " ");
                traverseTree(inputParent.getLeftChild());
                traverseTree(inputParent.getRightChild());
            }
        }
    }
}
