﻿using System;

namespace Trees
{
    class Program
    {
        // Variable declaration/assignment.
        static int[] myDataSet = new int[474];
        static dataManager myDataManager = new dataManager();
        static binaryTree myBinaryTree = new binaryTree();
        static Quick myQuickSort = new Quick();
        static bool isSorted = false;

        static void Main()
        {
            // Program entry point.

            // Populates myDataSet with values.
            populateDataSet();

            // Displays unsorted data set to console.
            displayDataSet();

            // Sorts data set.
            sortData();

            // Dsiplays sorted data set to console.
            displayDataSet();

            // Constructs Binary Tree data structure.
            constructTree();

            // Displays Binary Tree to console.
            // Root -> Left subtree -> Right subtree
            displayTree();

            // Program exit point.
        }

        // Invokes readFile method on myDataManager to populate myDataSet array.
        static void populateDataSet()
        {
            myDataSet = myDataManager.readFile();
        }

        // Invokes traverseTree method on myBinaryTree to display Binary Tree to the console.
        static void displayTree()
        {
            // Displays data set by PreOrder traversal. 
            // First Root
            // Left subtree
            // Right subtree
            Console.WriteLine("PreOrder Traversal (Root -> left subtree -> right subtree)");
            myBinaryTree.traverseTree(myBinaryTree.getRoot());
            Console.WriteLine("\n");
        }

        // Iteratively invokes addChild on myBinaryTree, passing in element in myDataSet at index i to construct Binary Tree.
        static void constructTree()
        {
            // Iterate over data set and construct binary tree data structure.
            for (int i = 0; i < myDataSet.Length; i++)
            {
                // add node with value at index i to proper position in tree. 
                myBinaryTree.addChild(myDataSet[i]);
            }
        }

        // Invokes QuickSort method on myQuickSort, passing in myDataSet, and the lower and upper bounds of myDataSet.
        static void sortData()
        {
            myQuickSort.QuickSort(myDataSet, myDataSet.GetLowerBound(0), myDataSet.GetUpperBound(0));
            isSorted = true;
        }

        // Displays myDataSet to the console.
        // Evaluates if dataSet has been sorted or not for output formatting.
        static void displayDataSet()
        {
            // Runs prior to sorting.
            if (!isSorted)
            {
                // Displays data set before sorting or binary tree construction.
                Console.WriteLine("Initial Data Set:");
                for (int i = 0; i < myDataSet.Length; i++)
                {
                    Console.Write(myDataSet[i] + " ");
                }
                Console.WriteLine("\n");
            }

            // Runs after sorting.
            if (isSorted)
            {
                // Display sorted data set.
                // Sorted with Quick sort method.
                Console.WriteLine("Sorted Data Set:");
                for (int i = 0; i < myDataSet.Length; i++)
                {
                    Console.Write(myDataSet[i] + " ");
                }
                Console.WriteLine("\n");
            }
        }
    }
}
