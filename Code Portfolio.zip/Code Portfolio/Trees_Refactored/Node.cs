﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trees
{
    class Node
    {
        // Node Class member variables.
        private Node leftChild;
        private Node rightChild;
        private int value;

        // get member methods.

        // Returns left child node.
        public Node getLeftChild()
        {
            return leftChild;
        }

        // Returns right child node.
        public Node getRightChild()
        {
            return rightChild;
        }

        // Returns node value.
        public int getNodeValue()
        {
            return value;
        }


        // Set member methods

        // Takes node as argument.
        // Assigns passed in node to left child node.
        public void setLeftChild(Node inputNode)
        {
            leftChild = inputNode;
        }

        // Takes node as argument.
        // Assigns passed in node to right child node.
        public void setRightChild(Node inputNode)
        {
            rightChild = inputNode;
        }

        // Takes integer as argument.
        // Assigns passed in integer to node value.
        public void setNodeValue(int inputValue)
        {
            value = inputValue;
        }
    }
}
