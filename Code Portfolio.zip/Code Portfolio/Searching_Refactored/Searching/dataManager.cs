﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Searching
{
    // dataManager is a helper class.
    // Manages data in program.
    class dataManager
    {
        // Class member variable declaration/instantiation.
        public int[] dataCopy = new int[10];

        // CopyData returns a new array that is a copy of inputData.
        // Takes an integer array as its argument.
        public int[] CopyData(int[] inputData)
        {
            // Iterate over array.
            for (int i = 0; i < inputData.Length; i++)
            {
                // Value of element at index i in dataCopy set to value of element in inputData array at index i.
                dataCopy[i] = inputData[i];
            }

            return dataCopy;
        }

        // Outputs array to the console as a comma delimited list for readability.
        public void displayData()
        {
            Console.WriteLine("[{0}]", string.Join(", ", dataCopy));
        }

        // Queries user for value to be searched. 
        public int getUserValue()
        {
            int value;
            Console.WriteLine("Input value that you would like to find:");

            // Loop until user enters valid input.
            while (true)
            {
                // Check input is valid. 
                if (Int32.TryParse(Console.ReadLine(), out value))
                {
                    return value;
                }
                else
                    Console.WriteLine("Invalid input. Please input a value in list.");
            }
        }
    }
}
