﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3_DataStructures
{
    class StackAndQueue
    {
        // Class member variable declaration/assignment.
        public static Stack<string> myStack = new Stack<string>();
        public static Queue<string> myQueue = new Queue<string>();

        // adds inputString to myStack
        public void pushStack(string inputString)
        {
            myStack.Push(inputString);
        }
    }
}
