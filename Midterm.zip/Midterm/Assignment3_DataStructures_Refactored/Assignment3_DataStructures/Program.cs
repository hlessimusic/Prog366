﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace Assignment3_DataStructures
{
    class Program
    {
        // Variable declaration/assignment.
        static FileManager myFileManager = new FileManager();
        static string myFilePath = @"..\\TextFile1.txt";
        static Hashtable myHash = new Hashtable();
        static string[] myArray = new string[myFileManager.testArray.Length];
        static Stack<string> myStack = new Stack<string>();
        static Queue<string> myQueue = new Queue<string>();

        static void Main()
        {
            // Program entry point

            loadFile();
            populateDataStructs();
            displayProgram();

            // Program exit point.
        }

        // Invokes loadFileToArrayMethod on myFileManager
        static void loadFile()
        {
            myFileManager.loadFileToArray(myFilePath);
        }

        // Populates myHash with data retreived from file.
        static void populateHashtable()
        {
            for (int i = 0; i < myFileManager.testArray.Length; i++)
            {
                myHash.Add(i, myFileManager.testArray[i]);
            }
        }

        // Prints myHash to the Console.
        static void printHashtable()
        {
            for (int i = 0; i < myHash.Count; i++)
            {
                Console.WriteLine(myHash[i]);
            }
        }

        // Populates myArray with data retreived from file.
        static void populateArray()
        {
            for (int i = 0; i < myFileManager.testArray.Length; i++)
            {
                myArray[i] = myFileManager.testArray[i];
            }
        }

        // Prints myArray to the Console.
        static void printArray()
        {
            for (int i = 0; i < myArray.Length; i++)
            {
                Console.WriteLine(myArray[i]);
            }
        }

        // Populates myStack with data retreived from file.
        static void populateStack()
        {
            for (int i = myFileManager.testArray.Length - 1; i >= 0; i--)
            {
                myStack.Push(myFileManager.testArray[i]);
            }
        }

        // Prints myStack to the Console.
        static void printStack()
        {
            foreach (var value in myStack)
            {
                Console.WriteLine(value);
            }
        }

        // Populates myQueue with data retreived from file.
        static void populateQueue()
        {
            for (int i = 0; i < myFileManager.testArray.Length; i++)
            {
                myQueue.Enqueue(myFileManager.testArray[i]);
            }
        }

        // Prints myQueue to the Console.
        static void printQueue()
        {
            foreach (var value in myQueue)
            {
                Console.WriteLine(value);
            }
        }

        // Calls Populate methods to populate all data structures.
        private static void populateDataStructs()
        {
            populateHashtable();
            populateArray();
            populateStack();
            populateQueue();
        }

        // Displays data structures to the console.
        // Calls print methods for each data structure.
        private static void displayProgram()
        {
            Console.WriteLine("Hashtable");
            printHashtable();
            Console.WriteLine();
            Console.WriteLine("Array");
            printArray();
            Console.WriteLine();
            Console.WriteLine("Stack");
            printStack();
            Console.WriteLine();
            Console.WriteLine("Queue");
            printQueue();
            Console.WriteLine();
            Console.ReadLine();
        }
    }
}
